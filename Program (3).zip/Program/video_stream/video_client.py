# @TODO: Implement on API side

class VideoClient:
    def __init__(self):
        raise NotImplementedError()
    
    def connect(self):
        raise NotImplementedError()
        
    def disconnect(self):
        raise NotImplementedError()
